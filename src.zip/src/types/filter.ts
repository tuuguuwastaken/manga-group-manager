export interface FilterType {
    firstName?: string
    lastName?: string
    email?: string
    phoneNumber?: string
    singleSearch?: string
}