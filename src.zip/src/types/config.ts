export interface ConfigType {
    orgId: string,
    path: string,
}