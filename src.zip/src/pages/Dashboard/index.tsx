const Dashboard = () => {
  return <>Dashboard</>
}

export default Dashboard
